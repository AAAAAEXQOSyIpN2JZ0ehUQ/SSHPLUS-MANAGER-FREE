<?php 
require_once("adm/system/funcoes.php");
require_once("adm/system/seguranca.php");
		$usuario = $_POST['login'];
		$senha = $_POST['senha'];
if(empty($usuario)){
	echo '<script type="text/javascript">';
	echo 'alert("Usuario em branco!");';
	echo 'window.location="login.php";';
	echo '</script>';
}
elseif(empty($senha)){
	echo '<script type="text/javascript">';
	echo 'alert("Senha em branco!");';
	echo 'window.location="login.php";';
	echo '</script>';
}else{

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
		$usuario = (isset($usuario)) ? $usuario : '';
        $senha = (isset($senha)) ? $senha : '';
    if (validaUsuario($usuario, $senha,"admin") == true) {
			echo '<script type="text/javascript">';
			echo 'alert("Bem Vindo a Pagina de Upload!");';
			echo 'window.location="home.php";';
			echo '</script>';
	}else{
			echo '<script type="text/javascript">';
			echo 'alert("Dados incorreto");';
			echo 'window.location="login.php";';
			echo '</script>';
		}	
	}
}
?>
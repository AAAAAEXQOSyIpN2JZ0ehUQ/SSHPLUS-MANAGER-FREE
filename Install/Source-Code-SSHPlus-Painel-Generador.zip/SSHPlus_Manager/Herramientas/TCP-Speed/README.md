﻿# TCP-Tweaker-1.0 (TCP-SPEED)

![logo](https://github.com/AAAAAEXQOSyIpN2JZ0ehUQ/SSHPLUS-MANAGER-FREE/blob/master/Imagenes/TCP_Tweaker_TCP_SPEED.jpg)

```
TCP TWEAKER 1.0 es una escritura experimental que cambia algunas configuraciones de red del sistema 
                 Linux para mejorar la velocidad y la estabilidad de la conexión proxy, VPN o túnel 
                 SSH. Si los cambios no mejoran la navegación y la estabilidad, basta con ejecutar 
                 la secuencia de comandos de nuevo para deshacerlas.
                 Comandos para executar: ./tcptweaker.sh 
```

## :book: Installation

apt-get update -y; apt-get upgrade -y; wget https://raw.githubusercontent.com/AAAAAEXQOSyIpN2JZ0ehUQ/SSHPLUS-MANAGER-FREE/master/Install/TCP-Speed/tcptweaker.sh; chmod +x tcptweaker.sh; ./tcptweaker.sh

```
Despues solo necesitara ejecutar la siguiente linea para usar nuevamente: ./tcptweaker.sh
```
-------------------------------------------------------------------------------

## :scroll: Changelog

**VERSION: 1.0**

https://raw.githubusercontent.com/AAAAAEXQOSyIpN2JZ0ehUQ/SSHPLUS-MANAGER-FREE/master/Install/TCP-Speed/versao

##

1. @Phreaker56- Developer of TCP-Tweaker-1.0 (TCP-SPEED)
2. illuminati Dev Team - Contributor 

```
☆ https://t.me/AAAAAEXQOSyIpN2JZ0ehUQ [  ⃘⃤꙰✰ ] ☆
```

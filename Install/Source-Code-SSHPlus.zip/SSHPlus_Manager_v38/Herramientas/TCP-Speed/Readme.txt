# TCP-Tweaker-1.0 (TCP-SPEED)

TCP TWEAKER 1.0 es una script experimental que cambia algunas configuraciones de red del sistema 
Linux para mejorar la velocidad y la estabilidad de la conexion proxy, VPN o tunel 
SSH. Si los cambios no mejoran la navegacion y la estabilidad, basta con ejecutar 
la secuencia de comandos ./tcptweaker.sh de nuevo para deshacerlas.
 
## Credits

	SCRIPT: 		TCP-Tweaker-1.0 (TCP-SPEED)
	CONTATO TELEGRAM: 	https://t.me/Phreaker56
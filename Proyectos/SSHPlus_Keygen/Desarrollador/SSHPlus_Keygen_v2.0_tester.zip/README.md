﻿```
* UPDATE 09/08/2021 - Proyecto Descontinuado
* GENERADOR DE KEY SSHPLUS MANAGER (Final Versión 2.0 BETA)
```
![logo](https://github.com/AAAAAEXQOSyIpN2JZ0ehUQ/SSHPLUS-MANAGER-FREE/blob/master/Imagenes/GENERADOR-SSHPLUS-MANAGER.png)

# GENERADOR DE KEY SSHPLUS MANAGER

## :book: Installation
```bash
apt-get update -y
```
```bash
apt-get upgrade -y
```
```bash
wget https://raw.githubusercontent.com/AAAAAEXQOSyIpN2JZ0ehUQ/SSHPLUS-MANAGER-FREE/master/Install/Generador/instgerador.sh && chmod +x instgerador.sh* && ./instgerador.sh*
```
DATA: El generador trabaja con Apache2 en el Puerto 80

## :scroll: Changelog
**VERSION: 2.0 BETA**
* [Details](https://raw.githubusercontent.com/AAAAAEXQOSyIpN2JZ0ehUQ/SSHPLUS-MANAGER-FREE/master/Install/Generador/versao)

## :heavy_exclamation_mark: Requirements
* Sistema operativo basado en Linux (Ubuntu o Debian)
* Versiones recomendadas: Ubuntu 18.04 Server x86_64 / Ubuntu 20.04 Server x86_64, Debian 9 Server x86_64
* Se sugiere utilizar una distribución reciente o recién formateada
* El idioma predeterminado es el portugués

## :octocat: Credits
1. [@crazy_vpn](https://t.me/crazy_vpn) - Developer of SSHPlus Manager
2. [illuminati Dev Team](https://t.me/AAAAAEXQOSyIpN2JZ0ehUQ) - Contributor
```
☆ https://t.me/AAAAAEXQOSyIpN2JZ0ehUQ [  ⃘⃤꙰✰ ] ☆
```

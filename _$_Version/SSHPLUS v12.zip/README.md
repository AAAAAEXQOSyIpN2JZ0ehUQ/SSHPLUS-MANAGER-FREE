﻿# SSHPLUS-MANAGER-FREE

![logo](https://raw.githubusercontent.com/AAAAAEXQOSyIpN2JZ0ehUQ/SSHPLUS-MANAGER-FREE/master/SSHPLUS_MANAGER.jpg)

Manager Script

1 • RECOMENDADO DEBIAN Y UBUNTU. ALGUNOS DE ELLOS TAMBIÉN PUEDEN FUNCIONAR CON CENTOS.

2 • USAR DISTRIBUCION NUEVA O FORMATIADA

apt-get update -y; apt-get upgrade -y; wget https://raw.githubusercontent.com/AAAAAEXQOSyIpN2JZ0ehUQ/SSHPLUS-MANAGER-FREE/master/sshplus.sh; chmod +x sshplus.sh; ./sshplus.sh

================================================================================

# TCP-Tweaker-1.0 (TCP-SPEED)

wget https://raw.githubusercontent.com/AAAAAEXQOSyIpN2JZ0ehUQ/HERRAMIENTAS/master/TCP-Tweaker-1.0/tcptweaker.sh; chmod +x tcptweaker.sh; ./tcptweaker.sh

============================
# PanelSSH de Ventas V10 Y V11

wget https://raw.githubusercontent.com/AAAAAEXQOSyIpN2JZ0ehUQ/ADM-ULTIMATE-NEW-FREE/master/Install/Panel_Web/install_panelweb.sh; chmod +x install_panelweb.sh; ./install_panelweb.sh

================================================================================

*SIN MINERIA! *SIN KEYS! *VERSION GRATUITA *SIN VIRUS TROJANO (BOTNET) *ARCHIVOS LIBERADOS (DECENCRIPTADOS)

================================================================================

☆ https://t.me/admmanagerfree ☆
=================================================

